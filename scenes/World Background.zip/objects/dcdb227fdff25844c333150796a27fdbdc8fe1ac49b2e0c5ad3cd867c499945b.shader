{
    "name"      : "Refraction",
    "preview"   : false,

    "blendMode"     : "alphablend",
    "renderLayer"   : "transparent",

    "uniforms": [
        {
            "displayName"   : "Refractivity",
            "name"          : "refractivity",
            "type"          : "float",
            "value"         : 0.5,
            "min"           : 0,
            "max"           : 1,
            "uniform"       : "u_refractive_factor"
        }, {
            "displayName"   : "Influence",
            "name"          : "Influence",
            "type"          : "float",
            "value"         : 0.5,
            "min"           : 0,
            "max"           : 1,
            "uniform"       : "u_influence"
        }, {
            "displayName"   : "Transparency",
            "name"          : "Transparency",
            "type"          : "float",
            "value"         : 1.0,
            "min"           : 0,
            "max"           : 1,
            "uniform"       : "u_alpha"
        }, {
            "displayName"   : "Sky Texture",
            "name"          : "texture",
            "type"          : "texture",
            "value"         : "",
            "uniform"       : "u_skyTexture",
            "toggle"        : "u_useSkyTexture"
        }
    ],
    "builtin": false,
}
